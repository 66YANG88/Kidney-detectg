"""
Medical Image Viewer - Mini 3D Slicer
Flask backend for loading, caching, and serving medical images.
"""

import os
import io
import math
import hashlib
import pickle
import glob
import threading
import uuid
import time
import shutil
import tempfile
from copy import deepcopy
from typing import Tuple, Union

import numpy as np
import SimpleITK as sitk
import blosc2
from PIL import Image
from flask import Flask, render_template, request, jsonify, send_file

app = Flask(__name__)

# ============================================================
# Configuration
# ============================================================
DATA_DIR = "/data/nnUNet_data/nnUNet_raw/Dataset001_KidneyCyst/imagesTs"
#nnUNet_raw/Dataset001_KidneyCyst/imagesTs
CACHE_DIR = "/data/medical_viewer/cache"
os.makedirs(CACHE_DIR, exist_ok=True)

# In-memory store for loaded volumes and metadata
loaded_volumes = {}
loaded_metadata = {}

# ============================================================
# nnUNet Inference Engine
# ============================================================
MODEL_DIR = "/data/nnUNet_data/nnUNet_results/Dataset001_KidneyCyst/nnUNetTrainer__nnUNetPlans__3d_fullres"
INPUT_DATA_DIR = "/data/nnUNet_data/nnUNet_raw/Dataset001_KidneyCyst/imagesTs"
INFERENCE_OUTPUT_DIR = "/data/nnUNet_data/window_inference_output"
os.makedirs(INFERENCE_OUTPUT_DIR, exist_ok=True)

os.environ.setdefault("nnUNet_raw", "/data/nnUNet_data/nnUNet_raw")
os.environ.setdefault("nnUNet_preprocessed", "/data/nnUNet_data/nnUNet_preprocessed")
os.environ.setdefault("nnUNet_results", "/data/nnUNet_data/nnUNet_results")

# Global inference state
inference_tasks = {}   # task_id -> {status, progress, message, result_path, ...}
inference_lock = threading.Lock()
_predictor = None
_predictor_lock = threading.Lock()
_cancel_flags = {}     # task_id -> threading.Event

# Segmentation label color map (3D Slicer style)
# Label 0 = background (transparent), Label 1 = kidney (green), Label 2 = cyst (yellow)
SEG_COLORS = {
    1: (0, 255, 0),      # kidney - green
    2: (255, 255, 0),    # cyst - yellow
}


def get_predictor():
    """Lazy-load the nnUNet predictor (thread-safe)."""
    global _predictor
    if _predictor is not None:
        return _predictor
    with _predictor_lock:
        if _predictor is not None:
            return _predictor
        import torch
        from nnunetv2.inference.predict_from_raw_data import nnUNetPredictor
        predictor = nnUNetPredictor(
            tile_step_size=0.5,
            use_gaussian=True,
            use_mirroring=True,
            perform_everything_on_device=True,
            device=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
            verbose=True,
            verbose_preprocessing=False,
            allow_tqdm=True,
        )
        predictor.initialize_from_trained_model_folder(
            model_training_output_dir=MODEL_DIR,
            use_folds=(0,),
            checkpoint_name="checkpoint_best.pth",
        )
        _predictor = predictor
        return _predictor


import re as _re
import sys as _sys

class _TqdmProgressCapture:
    """Intercept sys.stderr to parse tqdm progress and update task state."""
    def __init__(self, task_id, base_pct=30, range_pct=55):
        self.task_id = task_id
        self.base_pct = base_pct
        self.range_pct = range_pct  # 30%~85% for sliding window inference
        self._buf = ''
        self._orig = None

    def __enter__(self):
        self._orig = _sys.stderr
        _sys.stderr = self
        return self

    def __exit__(self, *args):
        _sys.stderr = self._orig

    def write(self, text):
        self._buf += text
        # Parse tqdm output: looks like "32/80 [00:22<00:32]"
        for m in _re.finditer(r'(\d+)/(\d+)\s*\[', self._buf):
            cur = int(m.group(1))
            total = int(m.group(2))
            if total > 0:
                pct = int(self.base_pct + self.range_pct * cur / total)
                _update_task(self.task_id, progress=pct,
                             message=f'正在推理滑窗... ({cur}/{total})')
        # Keep only last partial line to avoid re-matching
        if '\n' in self._buf or '\r' in self._buf:
            self._buf = self._buf.split('\r')[-1].split('\n')[-1]
        if self._orig:
            self._orig.write(text)

    def flush(self):
        if self._orig:
            self._orig.flush()

    def isatty(self):
        return False


def _update_task(task_id, **kwargs):
    """Thread-safe update of inference task state."""
    with inference_lock:
        if task_id in inference_tasks:
            inference_tasks[task_id].update(kwargs)


def _run_inference_single(task_id, input_filepath, output_dir):
    """Run inference on a single case in a background thread."""
    try:
        _update_task(task_id, status='loading', progress=5, message='正在加载模型...')
        if _cancel_flags.get(task_id, threading.Event()).is_set():
            _update_task(task_id, status='cancelled', progress=0, message='已取消')
            return

        predictor = get_predictor()

        _update_task(task_id, status='preprocessing', progress=15, message='正在预处理...')
        if _cancel_flags.get(task_id, threading.Event()).is_set():
            _update_task(task_id, status='cancelled', progress=0, message='已取消')
            return

        # Copy input to temp dir (nnUNet needs a folder)
        with tempfile.TemporaryDirectory() as tmp_in, tempfile.TemporaryDirectory() as tmp_out:
            src_name = os.path.basename(input_filepath)
            shutil.copy2(input_filepath, os.path.join(tmp_in, src_name))

            _update_task(task_id, status='inferring', progress=30, message='正在推理...')

            with _TqdmProgressCapture(task_id, base_pct=30, range_pct=55):
                predictor.predict_from_files(
                    list_of_lists_or_source_folder=tmp_in,
                    output_folder_or_list_of_truncated_output_files=tmp_out,
                    save_probabilities=False,
                    overwrite=True,
                    num_processes_preprocessing=2,
                    num_processes_segmentation_export=2,
                    folder_with_segs_from_prev_stage=None,
                    num_parts=1,
                    part_id=0,
                )

            _update_task(task_id, status='postprocessing', progress=85, message='正在后处理...')

            # Find result file
            case_name = src_name.replace("_0000.nii.gz", ".nii.gz")
            result_file = os.path.join(tmp_out, case_name)
            if not os.path.exists(result_file):
                results = glob.glob(os.path.join(tmp_out, "*.nii.gz"))
                if not results:
                    _update_task(task_id, status='error', progress=0, message='推理未生成结果文件')
                    return
                result_file = results[0]
                case_name = os.path.basename(result_file)

            # Copy result to output_dir
            dest_file = os.path.join(output_dir, case_name)
            shutil.copy2(result_file, dest_file)

        _update_task(task_id, status='caching', progress=92, message='正在缓存分割结果...')

        # Load and cache segmentation with blosc2
        seg_volume, seg_metadata = load_nifti_image(dest_file)
        seg_key = input_filepath + "_seg"
        loaded_volumes[seg_key] = seg_volume
        loaded_metadata[seg_key] = seg_metadata

        _update_task(task_id, status='done', progress=100,
                     message='推理完成',
                     result_path=dest_file,
                     seg_key=seg_key)

    except Exception as e:
        _update_task(task_id, status='error', progress=0, message=f'推理失败: {str(e)}')
        import traceback
        traceback.print_exc()


def _run_inference_batch(task_id, input_files, output_dir):
    """Run batch inference on multiple cases in a background thread."""
    total = len(input_files)
    completed = 0
    results = []

    try:
        _update_task(task_id, status='loading', progress=2, message='正在加载模型...')
        predictor = get_predictor()

        for i, input_filepath in enumerate(input_files):
            if _cancel_flags.get(task_id, threading.Event()).is_set():
                _update_task(task_id, status='cancelled', progress=0, message='已取消')
                return

            case_name_raw = os.path.basename(input_filepath)
            case_name_out = case_name_raw.replace("_0000.nii.gz", ".nii.gz")
            dest_file = os.path.join(output_dir, case_name_out)

            # Always re-infer (never skip existing results)
            pct = int(5 + 90 * i / total)
            _update_task(task_id, status='inferring', progress=pct,
                         message=f'正在推理 ({i+1}/{total}): {case_name_raw}',
                         completed=completed, total=total)

            with tempfile.TemporaryDirectory() as tmp_in, tempfile.TemporaryDirectory() as tmp_out:
                shutil.copy2(input_filepath, os.path.join(tmp_in, case_name_raw))
                predictor.predict_from_files(
                    list_of_lists_or_source_folder=tmp_in,
                    output_folder_or_list_of_truncated_output_files=tmp_out,
                    save_probabilities=False, overwrite=True,
                    num_processes_preprocessing=2,
                    num_processes_segmentation_export=2,
                    num_parts=1, part_id=0,
                )
                result_file = os.path.join(tmp_out, case_name_out)
                if not os.path.exists(result_file):
                    found = glob.glob(os.path.join(tmp_out, "*.nii.gz"))
                    if found:
                        result_file = found[0]
                        case_name_out = os.path.basename(result_file)
                        dest_file = os.path.join(output_dir, case_name_out)

                shutil.copy2(result_file, dest_file)

            # Cache segmentation in memory (key: input_filepath + "_seg")
            seg_vol, seg_meta = load_nifti_image(dest_file)
            seg_key = input_filepath + "_seg"
            loaded_volumes[seg_key] = seg_vol
            loaded_metadata[seg_key] = seg_meta
            completed += 1
            results.append({'seg_path': dest_file, 'input_path': input_filepath,
                             'case_name': case_name_out})

        _update_task(task_id, status='done', progress=100,
                     message=f'批量推理完成 ({completed}/{total})',
                     completed=completed, total=total, results=results)

    except Exception as e:
        _update_task(task_id, status='error', progress=0, message=f'批量推理失败: {str(e)}')
        import traceback
        traceback.print_exc()


# ============================================================
# Blosc2 cache utilities (adapted from nnUNet)
# ============================================================
def comp_blosc2_params(
        image_size: Tuple[int, ...],
        bytes_per_pixel: int = 4,
        l1_cache_size_per_core_in_bytes=32768,
        l3_cache_size_per_core_in_bytes=1441792,
        safety_factor: float = 0.8
):
    """
    Compute recommended block and chunk sizes for blosc2 storage.
    Simplified from nnUNet's nnUNetDatasetBlosc2.comp_blosc2_params.
    """
    ndim = len(image_size)
    block_size = np.array([2 ** max(0, math.ceil(math.log2(s))) for s in image_size])

    # Shrink block to fit L1 cache
    estimated_nbytes = np.prod(block_size) * bytes_per_pixel
    while estimated_nbytes > (l1_cache_size_per_core_in_bytes * safety_factor):
        # Pick largest axis that is > 1
        largest_axis = -1
        largest_val = 0
        for ax in range(ndim):
            if block_size[ax] > 1 and block_size[ax] > largest_val:
                largest_val = block_size[ax]
                largest_axis = ax
        if largest_axis == -1:
            break
        block_size[largest_axis] = 2 ** max(0, math.floor(
            math.log2(block_size[largest_axis] - 1)))
        block_size[largest_axis] = min(block_size[largest_axis],
                                       image_size[largest_axis])
        estimated_nbytes = np.prod(block_size) * bytes_per_pixel

    block_size = np.array([min(i, j) for i, j in zip(image_size, block_size)])

    # Expand chunks to use L3 cache
    chunk_size = deepcopy(block_size)
    estimated_nbytes = np.prod(chunk_size) * bytes_per_pixel
    while estimated_nbytes < (l3_cache_size_per_core_in_bytes * safety_factor):
        if all(i == j for i, j in zip(chunk_size, image_size)):
            break
        # Find axis with smallest chunk/block ratio
        ratios = chunk_size / block_size
        axis_order = np.argsort(ratios)
        picked = None
        for ax in axis_order:
            if chunk_size[ax] < image_size[ax]:
                picked = ax
                break
        if picked is None:
            break
        chunk_size[picked] += block_size[picked]
        chunk_size[picked] = min(chunk_size[picked], image_size[picked])
        estimated_nbytes = np.prod(chunk_size) * bytes_per_pixel

    chunk_size = [min(i, j) for i, j in zip(image_size, chunk_size)]
    return tuple(block_size), tuple(chunk_size)


def get_cache_key(filepath):
    """Generate a unique cache key from filepath and modification time."""
    stat = os.stat(filepath)
    key_str = f"{filepath}_{stat.st_mtime}_{stat.st_size}"
    return hashlib.md5(key_str.encode()).hexdigest()


def save_to_blosc2_cache(array: np.ndarray, cache_path: str):
    """Save numpy array to blosc2 format with optimized parameters."""
    block_size, chunk_size = comp_blosc2_params(
        array.shape, bytes_per_pixel=array.itemsize)
    blosc2.asarray(
        array,
        chunks=chunk_size,
        blocks=block_size,
        urlpath=cache_path,
        mode='w',
        cparams=blosc2.CParams(codec=blosc2.Codec.ZSTD, clevel=3)
    )


def load_from_blosc2_cache(cache_path: str) -> np.ndarray:
    """Load numpy array from blosc2 cache."""
    arr = blosc2.open(cache_path, mode='r')
    return arr[:]


# ============================================================
# Image loading with coordinate system handling
# ============================================================
def load_nifti_image(filepath: str):
    """
    Load a NIfTI image with proper coordinate system handling.
    Converts from SimpleITK's LPS to RAS (3D Slicer standard).
    Returns volume data (numpy), and metadata dict.
    """
    cache_key = get_cache_key(filepath)
    cache_data_path = os.path.join(CACHE_DIR, f"{cache_key}_data.b2nd")
    cache_meta_path = os.path.join(CACHE_DIR, f"{cache_key}_meta.pkl")

    # Check cache first
    if os.path.exists(cache_data_path) and os.path.exists(cache_meta_path):
        volume = load_from_blosc2_cache(cache_data_path)
        with open(cache_meta_path, 'rb') as f:
            metadata = pickle.load(f)
        return volume, metadata

    # Read with SimpleITK
    image = sitk.ReadImage(filepath)

    # Reorient to RAS coordinate system (3D Slicer standard)
    # SimpleITK default is LPS; DICOMOrientImageToCoordinateAxes converts to target
    try:
        image_ras = sitk.DICOMOrientImageToCoordinateAxes(image, 'RAS')
    except Exception:
        # Fallback: manual LPS -> RAS conversion
        image_ras = sitk.Flip(image, [True, True, False])
        # Adjust origin for flipped axes
        orig = list(image.GetOrigin())
        size = list(image.GetSize())
        spacing = list(image.GetSpacing())
        orig[0] = -(orig[0] + (size[0] - 1) * spacing[0])
        orig[1] = -(orig[1] + (size[1] - 1) * spacing[1])
        image_ras.SetOrigin(tuple(orig))

    # Extract metadata in RAS
    spacing = image_ras.GetSpacing()       # (x, y, z) in mm
    origin = image_ras.GetOrigin()         # (x, y, z) in mm
    direction = image_ras.GetDirection()   # 3x3 flattened
    size = image_ras.GetSize()             # (x, y, z)

    # Convert to numpy - SimpleITK GetArrayFromImage returns (z, y, x)
    volume = sitk.GetArrayFromImage(image_ras)  # shape: (Z, Y, X)

    metadata = {
        'spacing': list(spacing),      # [sx, sy, sz] in RAS
        'origin': list(origin),        # [ox, oy, oz] in RAS
        'direction': list(direction),  # 9 elements
        'size': list(size),            # [X, Y, Z]
        'numpy_shape': list(volume.shape),  # [Z, Y, X]
        'dtype': str(volume.dtype),
        'min_val': float(np.min(volume)),
        'max_val': float(np.max(volume)),
        'filename': os.path.basename(filepath),
    }

    # Save to blosc2 cache
    try:
        save_to_blosc2_cache(volume.astype(np.float32), cache_data_path)
        with open(cache_meta_path, 'wb') as f:
            pickle.dump(metadata, f)
    except Exception as e:
        print(f"Warning: cache save failed: {e}")

    return volume, metadata


def render_overlay(gray_img, seg_slice, opacity=0.4, mode='overlay'):
    """
    Render segmentation overlay on grayscale CT image.
    mode: 'overlay' = CT + colored seg, 'seg_only' = only colored seg on black bg
    Returns RGB PIL Image.
    """
    h, w = gray_img.shape[:2] if isinstance(gray_img, np.ndarray) else (np.array(gray_img).shape[:2])

    if mode == 'seg_only':
        # Black background with colored segmentation
        rgb = np.zeros((h, w, 3), dtype=np.uint8)
        for label, color in SEG_COLORS.items():
            mask = (seg_slice == label)
            for c in range(3):
                rgb[:, :, c][mask] = color[c]
        return Image.fromarray(rgb, mode='RGB')
    else:
        # Overlay: blend CT grayscale with colored segmentation
        if isinstance(gray_img, np.ndarray):
            if gray_img.ndim == 2:
                rgb = np.stack([gray_img, gray_img, gray_img], axis=-1).astype(np.float32)
            else:
                rgb = gray_img.astype(np.float32)
        else:
            rgb = np.array(gray_img.convert('RGB')).astype(np.float32)

        for label, color in SEG_COLORS.items():
            mask = (seg_slice == label)
            if not np.any(mask):
                continue
            seg_color = np.array(color, dtype=np.float32)
            for c in range(3):
                rgb[:, :, c][mask] = (
                    (1.0 - opacity) * rgb[:, :, c][mask] + opacity * seg_color[c]
                )

        return Image.fromarray(np.clip(rgb, 0, 255).astype(np.uint8), mode='RGB')


def get_seg_slice(filepath, plane, idx):
    """
    Get the segmentation slice matching an original image slice.
    Returns seg_slice numpy array or None.
    Only uses in-memory segmentation (loaded after inference).
    """
    seg_key = filepath + "_seg"
    if seg_key not in loaded_volumes:
        return None

    seg_volume = loaded_volumes[seg_key]

    try:
        if plane == 'axial':
            idx_c = min(max(0, idx), seg_volume.shape[0] - 1)
            seg_slice = seg_volume[idx_c, :, :]
            seg_slice = np.flipud(seg_slice)
            seg_slice = np.fliplr(seg_slice)
        elif plane == 'coronal':
            idx_c = min(max(0, idx), seg_volume.shape[1] - 1)
            seg_slice = seg_volume[:, idx_c, :]
            seg_slice = np.flipud(seg_slice)
            seg_slice = np.fliplr(seg_slice)
        elif plane == 'sagittal':
            idx_c = min(max(0, idx), seg_volume.shape[2] - 1)
            seg_slice = seg_volume[:, :, idx_c]
            seg_slice = np.flipud(seg_slice)
            seg_slice = np.fliplr(seg_slice)
        else:
            return None
        return seg_slice
    except (IndexError, Exception):
        return None


def apply_window(slice_data, ww, wl):
    """Apply window width/level (windowing) to slice data."""
    lower = wl - ww / 2.0
    upper = wl + ww / 2.0
    windowed = np.clip(slice_data, lower, upper)
    # Normalize to 0-255
    if upper > lower:
        windowed = ((windowed - lower) / (upper - lower) * 255.0)
    else:
        windowed = np.zeros_like(slice_data)
    return windowed.astype(np.uint8)


def apply_colormap(gray_img, colormap='gray'):
    """Apply colormap to grayscale image. Returns RGB PIL Image."""
    if colormap == 'gray':
        return Image.fromarray(gray_img, mode='L')
    elif colormap == 'hot':
        # Hot colormap: black -> red -> yellow -> white
        r = np.clip(gray_img * 3.0, 0, 255).astype(np.uint8)
        g = np.clip((gray_img - 85) * 3.0, 0, 255).astype(np.uint8)
        b = np.clip((gray_img - 170) * 3.0, 0, 255).astype(np.uint8)
        return Image.fromarray(np.stack([r, g, b], axis=-1), mode='RGB')
    elif colormap == 'cool':
        r = gray_img
        b = 255 - gray_img
        g = np.zeros_like(gray_img)
        return Image.fromarray(np.stack([r, g, b], axis=-1), mode='RGB')
    elif colormap == 'bone':
        # Bone-like colormap
        r = np.clip(gray_img * 0.85, 0, 255).astype(np.uint8)
        g = np.clip(gray_img * 0.85 + 20, 0, 255).astype(np.uint8)
        b = np.clip(gray_img * 0.95 + 10, 0, 255).astype(np.uint8)
        return Image.fromarray(np.stack([r, g, b], axis=-1), mode='RGB')
    return Image.fromarray(gray_img, mode='L')


def numpy_to_png_bytes(img):
    """Convert PIL Image to PNG bytes."""
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    return buf


# ============================================================
# Flask Routes
# ============================================================
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/files')
def list_files():
    """List available NIfTI files."""
    files = sorted(glob.glob(os.path.join(DATA_DIR, "*.nii.gz")))
    file_list = [{'name': os.path.basename(f), 'path': f} for f in files]
    return jsonify({'files': file_list})


@app.route('/api/load', methods=['POST'])
def load_image():
    """Load a NIfTI image and return metadata."""
    data = request.get_json()
    filepath = data.get('filepath', '')

    if not filepath or not os.path.exists(filepath):
        return jsonify({'error': 'File not found'}), 404

    try:
        volume, metadata = load_nifti_image(filepath)
        # Store in memory for fast slice access
        loaded_volumes[filepath] = volume
        loaded_metadata[filepath] = metadata
        return jsonify({
            'success': True,
            'metadata': metadata,
            'filepath': filepath
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/slice/<plane>/<int:idx>')
def get_slice(plane, idx):
    """
    Get a slice image.
    Query params: filepath, ww (window width), wl (window level),
                  colormap (gray/hot/cool/bone), invert (0/1)
    Volume shape is (Z, Y, X) in numpy after RAS reorientation.
    - Axial: slice along Z axis -> shows (Y, X) plane, viewed S->I
    - Coronal: slice along Y axis -> shows (Z, X) plane, viewed A->P
    - Sagittal: slice along X axis -> shows (Z, Y) plane, viewed R->L
    """
    filepath = request.args.get('filepath', '')
    ww = float(request.args.get('ww', 400))
    wl = float(request.args.get('wl', 40))
    colormap = request.args.get('colormap', 'gray')
    invert = request.args.get('invert', '0') == '1'
    overlay = request.args.get('overlay', 'none')   # none / overlay / seg_only
    seg_opacity = float(request.args.get('seg_opacity', 0.4))

    if filepath not in loaded_volumes:
        # Try to load
        if os.path.exists(filepath):
            volume, metadata = load_nifti_image(filepath)
            loaded_volumes[filepath] = volume
            loaded_metadata[filepath] = metadata
        else:
            return jsonify({'error': 'Volume not loaded'}), 404

    volume = loaded_volumes[filepath]
    # volume shape: (Z, Y, X)

    # After DICOMOrientImageToCoordinateAxes('RAS'):
    #   SimpleITK axes: axis0=R, axis1=A, axis2=S
    #   numpy (GetArrayFromImage reverses): axis0=S, axis1=A, axis2=R
    #   Direction: [-1,0,0, 0,-1,0, 0,0,1] in LPS
    #   => increasing numpy axis0 => more Superior
    #   => increasing numpy axis1 => more Anterior
    #   => increasing numpy axis2 => more Right
    #
    # Spacing order from SimpleITK: [R_spacing, A_spacing, S_spacing]

    spacing = loaded_metadata.get(filepath, {}).get('spacing', [1, 1, 1])

    try:
        if plane == 'axial':
            # Axial: slice along S (numpy axis 0), display (A, R) plane
            idx = min(max(0, idx), volume.shape[0] - 1)
            slice_data = volume[idx, :, :]  # shape (A, R)
            # 3D Slicer: Anterior at top, Right on left (radiological)
            slice_data = np.flipud(slice_data)   # A at top
            slice_data = np.fliplr(slice_data)   # R on left (radiological)
            row_spacing = spacing[1]  # A spacing
            col_spacing = spacing[0]  # R spacing
        elif plane == 'coronal':
            # Coronal: slice along A (numpy axis 1), display (S, R) plane
            idx = min(max(0, idx), volume.shape[1] - 1)
            slice_data = volume[:, idx, :]  # shape (S, R)
            # 3D Slicer: Superior at top, Right on left
            slice_data = np.flipud(slice_data)   # S at top
            slice_data = np.fliplr(slice_data)   # R on left
            row_spacing = spacing[2]  # S spacing
            col_spacing = spacing[0]  # R spacing
        elif plane == 'sagittal':
            # Sagittal: slice along R (numpy axis 2), display (S, A) plane
            idx = min(max(0, idx), volume.shape[2] - 1)
            slice_data = volume[:, :, idx]  # shape (S, A)
            # 3D Slicer: Superior at top, Anterior on left
            slice_data = np.flipud(slice_data)   # S at top
            slice_data = np.fliplr(slice_data)   # A on left
            row_spacing = spacing[2]  # S spacing
            col_spacing = spacing[1]  # A spacing
        else:
            return jsonify({'error': f'Unknown plane: {plane}'}), 400
    except IndexError:
        return jsonify({'error': 'Index out of range'}), 400

    # Apply windowing
    windowed = apply_window(slice_data.astype(np.float64), ww, wl)

    if invert:
        windowed = 255 - windowed

    # Handle overlay mode
    if overlay in ('overlay', 'seg_only'):
        seg_slice = get_seg_slice(filepath, plane, idx)
        if seg_slice is not None:
            # Resize seg_slice to match windowed if shapes differ
            if seg_slice.shape != windowed.shape:
                from PIL import Image as PILImage
                seg_img = PILImage.fromarray(seg_slice.astype(np.uint8), mode='L')
                seg_img = seg_img.resize((windowed.shape[1], windowed.shape[0]), PILImage.NEAREST)
                seg_slice = np.array(seg_img)
            img = render_overlay(windowed, seg_slice, opacity=seg_opacity, mode=overlay)
        else:
            # No segmentation available, fall back to original
            img = apply_colormap(windowed, colormap)
    else:
        # Apply colormap (original behavior)
        img = apply_colormap(windowed, colormap)

    # Correct aspect ratio for anisotropic spacing
    # Resize so pixel aspect matches physical aspect
    if abs(row_spacing - col_spacing) > 0.01:
        h, w = slice_data.shape
        physical_h = h * row_spacing
        physical_w = w * col_spacing
        # Scale to match the finer resolution axis
        fine_spacing = min(row_spacing, col_spacing)
        new_h = max(1, int(round(physical_h / fine_spacing)))
        new_w = max(1, int(round(physical_w / fine_spacing)))
        img = img.resize((new_w, new_h), Image.BILINEAR)

    return send_file(numpy_to_png_bytes(img), mimetype='image/png')


@app.route('/api/mip')
def get_mip():
    """
    Get Maximum Intensity Projection for 3D rendering.
    Query params: filepath, ww, wl, colormap, axis (0=coronal, 1=sagittal, 2=axial),
                  angle (rotation angle in degrees)
    """
    filepath = request.args.get('filepath', '')
    ww = float(request.args.get('ww', 400))
    wl = float(request.args.get('wl', 40))
    colormap = request.args.get('colormap', 'gray')
    proj_axis = int(request.args.get('axis', 1))  # default: sagittal projection

    if filepath not in loaded_volumes:
        if os.path.exists(filepath):
            volume, metadata = load_nifti_image(filepath)
            loaded_volumes[filepath] = volume
            loaded_metadata[filepath] = metadata
        else:
            return jsonify({'error': 'Volume not loaded'}), 404

    volume = loaded_volumes[filepath]
    spacing = loaded_metadata.get(filepath, {}).get('spacing', [1, 1, 1])

    # MIP along specified axis
    # Use wider window for MIP to capture bone structures
    mip = np.max(volume, axis=proj_axis).astype(np.float64)
    mip = np.flipud(mip)
    mip = np.fliplr(mip)

    windowed = apply_window(mip.astype(np.float64), ww, wl)
    img = apply_colormap(windowed, colormap)

    # Correct aspect ratio for anisotropic spacing in MIP
    # proj_axis: 0=S, 1=A, 2=R (numpy axes)
    # After projection along axis, remaining dims determine spacing
    spacing_map = {
        0: (spacing[1], spacing[0]),  # project S -> display (A, R) -> row=A, col=R
        1: (spacing[2], spacing[0]),  # project A -> display (S, R) -> row=S, col=R
        2: (spacing[2], spacing[1]),  # project R -> display (S, A) -> row=S, col=A
    }
    row_sp, col_sp = spacing_map.get(proj_axis, (1, 1))
    if abs(row_sp - col_sp) > 0.01:
        h, w = mip.shape
        fine = min(row_sp, col_sp)
        new_h = max(1, int(round(h * row_sp / fine)))
        new_w = max(1, int(round(w * col_sp / fine)))
        img = img.resize((new_w, new_h), Image.BILINEAR)

    return send_file(numpy_to_png_bytes(img), mimetype='image/png')


@app.route('/api/volume3d')
def get_volume3d():
    """
    Return volume data as a texture atlas PNG for WebGL 3D rendering.
    Query params:
      filepath  - path to the loaded volume
      ww, wl    - window width/level (for CT normalization)
      type      - 'ct' (default) or 'seg'
    Atlas layout: tiles_per_row = ceil(sqrt(Z)) slices per row, each tile = (Y, X)
    Response headers:
      X-Vol-Shape : "Z,Y,X"
      X-Vol-Tiles : tiles_per_row
      X-Vol-Spacing: "sx,sy,sz"
    """
    filepath = request.args.get('filepath', '')
    ww = float(request.args.get('ww', 400))
    wl = float(request.args.get('wl', 40))
    vol_type = request.args.get('type', 'ct')  # 'ct' or 'seg'

    if vol_type == 'seg':
        seg_key = filepath + '_seg'
        if seg_key not in loaded_volumes:
            return jsonify({'error': 'Segmentation not loaded'}), 404
        volume = loaded_volumes[seg_key]
    else:
        if filepath not in loaded_volumes:
            if os.path.exists(filepath):
                vol, meta = load_nifti_image(filepath)
                loaded_volumes[filepath] = vol
                loaded_metadata[filepath] = meta
            else:
                return jsonify({'error': 'Volume not loaded'}), 404
        volume = loaded_volumes[filepath]

    Z, Y, X = volume.shape
    spacing = loaded_metadata.get(filepath if vol_type == 'ct' else filepath,
                                   {}).get('spacing', [1.0, 1.0, 1.0])

    tiles_per_row = max(1, math.ceil(math.sqrt(Z)))
    rows_needed = math.ceil(Z / tiles_per_row)
    atlas_w = tiles_per_row * X
    atlas_h = rows_needed * Y

    if vol_type == 'seg':
        # Segmentation: raw uint8 label values (0/1/2), scale to 0/85/170 for visibility
        atlas = np.zeros((atlas_h, atlas_w), dtype=np.uint8)
        for z in range(Z):
            row = z // tiles_per_row
            col = z % tiles_per_row
            slc = volume[z, :, :].astype(np.uint8)
            # Scale: label 1 -> 85, label 2 -> 170, so shader can decode back
            slc = np.clip(slc, 0, 2).astype(np.uint8) * 85
            atlas[row*Y:(row+1)*Y, col*X:(col+1)*X] = slc
    else:
        # CT: apply windowing -> uint8
        atlas = np.zeros((atlas_h, atlas_w), dtype=np.uint8)
        lower = wl - ww / 2.0
        upper = wl + ww / 2.0
        for z in range(Z):
            row = z // tiles_per_row
            col = z % tiles_per_row
            slc = volume[z, :, :].astype(np.float64)
            slc = np.clip(slc, lower, upper)
            if upper > lower:
                slc = ((slc - lower) / (upper - lower) * 255.0)
            else:
                slc = np.zeros_like(slc)
            atlas[row*Y:(row+1)*Y, col*X:(col+1)*X] = slc.astype(np.uint8)

    img = Image.fromarray(atlas, mode='L')
    buf = io.BytesIO()
    img.save(buf, format='PNG', optimize=False, compress_level=1)
    buf.seek(0)

    response = send_file(buf, mimetype='image/png')
    response.headers['X-Vol-Shape'] = f'{Z},{Y},{X}'
    response.headers['X-Vol-Tiles'] = str(tiles_per_row)
    response.headers['X-Vol-Spacing'] = f"{spacing[0]},{spacing[1]},{spacing[2]}"
    response.headers['Access-Control-Expose-Headers'] = 'X-Vol-Shape,X-Vol-Tiles,X-Vol-Spacing'
    return response


@app.route('/api/histogram')
def get_histogram():
    """Get intensity histogram of loaded volume."""
    filepath = request.args.get('filepath', '')

    if filepath not in loaded_volumes:
        return jsonify({'error': 'Volume not loaded'}), 404

    volume = loaded_volumes[filepath]
    # Sample for performance (max 1M voxels)
    if volume.size > 1000000:
        flat = volume.flatten()
        indices = np.random.choice(len(flat), 1000000, replace=False)
        sample = flat[indices]
    else:
        sample = volume.flatten()

    hist, bin_edges = np.histogram(sample, bins=256)
    return jsonify({
        'counts': hist.tolist(),
        'bin_edges': bin_edges.tolist(),
        'min': float(np.min(volume)),
        'max': float(np.max(volume))
    })


# ============================================================
# Inference API Routes
# ============================================================
@app.route('/api/inference/start', methods=['POST'])
def start_inference():
    """Start inference on the currently displayed image."""
    data = request.get_json()
    filepath = data.get('filepath', '')

    if not filepath or not os.path.exists(filepath):
        return jsonify({'error': '文件不存在'}), 404

    task_id = str(uuid.uuid4())[:8]
    cancel_event = threading.Event()
    _cancel_flags[task_id] = cancel_event

    # Clear any previously cached segmentation for this file so the new result is used
    seg_key = filepath + "_seg"
    loaded_volumes.pop(seg_key, None)
    loaded_metadata.pop(seg_key, None)

    with inference_lock:
        inference_tasks[task_id] = {
            'status': 'queued',
            'progress': 0,
            'message': '排队中...',
            'result_path': None,
            'seg_key': None,
            'input_filepath': filepath,
        }

    t = threading.Thread(target=_run_inference_single,
                         args=(task_id, filepath, INFERENCE_OUTPUT_DIR), daemon=True)
    t.start()

    return jsonify({'task_id': task_id})


@app.route('/api/inference/batch', methods=['POST'])
def start_batch_inference():
    """Start batch inference on selected images (or all if none specified)."""
    data = request.get_json() or {}
    selected_paths = data.get('files', None)  # list of absolute paths or None

    if selected_paths is not None:
        # Validate each path
        input_files = [p for p in selected_paths if os.path.exists(p)]
        if not input_files:
            return jsonify({'error': '所选文件不存在'}), 404
    else:
        # Fallback: all test images
        input_files = sorted(glob.glob(os.path.join(INPUT_DATA_DIR, "*_0000.nii.gz")))
        if not input_files:
            return jsonify({'error': '未找到测试集图像'}), 404

    task_id = str(uuid.uuid4())[:8]
    cancel_event = threading.Event()
    _cancel_flags[task_id] = cancel_event

    # Clear old segmentation caches for all selected files
    for p in input_files:
        seg_key = p + "_seg"
        loaded_volumes.pop(seg_key, None)
        loaded_metadata.pop(seg_key, None)

    with inference_lock:
        inference_tasks[task_id] = {
            'status': 'queued',
            'progress': 0,
            'message': f'排队中... (共 {len(input_files)} 个案例)',
            'completed': 0,
            'total': len(input_files),
            'results': [],
        }

    t = threading.Thread(target=_run_inference_batch,
                         args=(task_id, input_files, INFERENCE_OUTPUT_DIR), daemon=True)
    t.start()

    return jsonify({'task_id': task_id, 'total': len(input_files)})


@app.route('/api/inference/progress/<task_id>')
def get_inference_progress(task_id):
    """Get inference progress."""
    with inference_lock:
        task = inference_tasks.get(task_id)
    if task is None:
        return jsonify({'error': '任务不存在'}), 404
    return jsonify(task)


@app.route('/api/inference/cancel/<task_id>', methods=['POST'])
def cancel_inference(task_id):
    """Cancel a running inference task."""
    cancel_event = _cancel_flags.get(task_id)
    if cancel_event:
        cancel_event.set()
        _update_task(task_id, status='cancelled', message='正在取消...')
        return jsonify({'success': True})
    return jsonify({'error': '任务不存在'}), 404


@app.route('/api/segmentation/check')
def check_segmentation():
    """Check if segmentation exists for a given image filepath (in-memory only)."""
    filepath = request.args.get('filepath', '')
    seg_key = filepath + "_seg"

    # Only check in-memory: do NOT auto-load from disk so that
    # stale results are never shown without re-running inference.
    if seg_key in loaded_volumes:
        return jsonify({'has_seg': True})

    return jsonify({'has_seg': False})


@app.route('/api/probe/label')
def get_probe_label():
    """
    Get segmentation label at a given voxel position.
    Query params: filepath, z, y, x (numpy indices: Z, Y, X)
    Returns label value and category name.
    """
    filepath = request.args.get('filepath', '')
    try:
        iz = int(request.args.get('z', 0))
        iy = int(request.args.get('y', 0))
        ix = int(request.args.get('x', 0))
    except (ValueError, TypeError):
        return jsonify({'error': '无效坐标'}), 400

    seg_key = filepath + '_seg'
    if seg_key not in loaded_volumes:
        # Only use in-memory segmentation; do not auto-load from disk
        return jsonify({'label': None, 'category': None})

    seg_volume = loaded_volumes[seg_key]
    try:
        iz_c = min(max(0, iz), seg_volume.shape[0] - 1)
        iy_c = min(max(0, iy), seg_volume.shape[1] - 1)
        ix_c = min(max(0, ix), seg_volume.shape[2] - 1)
        label = int(seg_volume[iz_c, iy_c, ix_c])
    except (IndexError, Exception):
        return jsonify({'label': None, 'category': None})

    LABEL_NAMES = {0: '背景', 1: '肾脏', 2: '囊肿'}
    category = LABEL_NAMES.get(label, f'未知({label})')
    return jsonify({'label': label, 'category': category})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
