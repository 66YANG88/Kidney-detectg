/**
 * Medical Image Viewer - Mini 3D Slicer
 * Frontend interaction logic
 */

// ============================================================
// WebGL2 Volume Renderer (Ray Casting)
// ============================================================
class VolumeRenderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.gl = canvas.getContext('webgl2', { antialias: false, alpha: false });
        if (!this.gl) { console.error('WebGL2 not supported'); return; }

        this._volTex = null;
        this._segTex = null;
        this._volShape = [1, 1, 1];   // [Z, Y, X]
        this._spacing = [1, 1, 1];    // [sx, sy, sz]
        this._mode = 0;               // 0=original,1=overlay,2=seg_only
        this._segOpacity = 0.4;
        this._stepSize = 0.004;

        // Arcball rotation state
        this._quat = [0, 0, 0, 1];    // identity quaternion
        this._zoom = 2.0;
        this._isDragging = false;
        this._lastMouse = [0, 0];

        this._program = null;
        this._vao = null;
        this._ready = false;
        this._ctLoaded = false;
        this._segLoaded = false;

        this._initGL();
        this._setupMouseEvents();
        this._ro = new ResizeObserver(() => this._resize());
        this._ro.observe(canvas.parentElement);
        this._resize();
    }

    _resize() {
        const c = this.canvas;
        const p = c.parentElement;
        const w = p.clientWidth  || 300;
        const h = p.clientHeight || 300;
        c.width  = w;
        c.height = h;
        if (this.gl) this.gl.viewport(0, 0, w, h);
        if (this._ready) this.render();
    }

    // ---------- GL init ----------
    _initGL() {
        const gl = this.gl;

        // Vertex shader: full-screen quad, compute ray direction
        const vsrc = `#version 300 es
        precision highp float;
        in vec2 a_pos;
        out vec2 v_uv;
        void main() {
            v_uv = a_pos * 0.5 + 0.5;
            gl_Position = vec4(a_pos, 0.0, 1.0);
        }`;

        // Fragment shader: ray casting through unit cube [0,1]^3
        const fsrc = `#version 300 es
        precision highp float;
        precision highp sampler3D;

        in vec2 v_uv;
        out vec4 fragColor;

        uniform sampler3D u_vol;        // CT data 0-1
        uniform sampler3D u_seg;        // seg labels: 0=bg, 1/3=kidney, 2/3=cyst
        uniform mat4 u_inv_rot;         // inverse rotation matrix
        uniform float u_zoom;           // camera distance factor
        uniform float u_aspect;         // canvas W/H
        uniform float u_step;           // ray step size
        uniform int   u_mode;           // 0=CT, 1=overlay, 2=seg_only
        uniform float u_seg_opacity;    // overlay opacity for seg labels
        uniform vec3  u_box_scale;      // physical size normalization

        // Intersect ray with unit cube [0,1]^3 -> returns (tmin, tmax)
        vec2 boxIntersect(vec3 ro, vec3 rd) {
            vec3 inv_rd = 1.0 / rd;
            vec3 t0 = (vec3(0.0) - ro) * inv_rd;
            vec3 t1 = (vec3(1.0) - ro) * inv_rd;
            vec3 tmin3 = min(t0, t1);
            vec3 tmax3 = max(t0, t1);
            float tmin = max(max(tmin3.x, tmin3.y), tmin3.z);
            float tmax = min(min(tmax3.x, tmax3.y), tmax3.z);
            return vec2(tmin, tmax);
        }

        void main() {
            // Reconstruct ray in object space
            vec2 ndc = v_uv * 2.0 - 1.0;
            ndc.x *= u_aspect;

            // Orthographic-style: zoom shrinks the visible window (smaller scale = zoomed in)
            float scale = 0.8 / u_zoom;
            vec3 ro_cam = vec3(ndc.x * scale, ndc.y * scale, -2.0);
            vec3 rd_cam = vec3(0.0, 0.0, 1.0);

            // Apply inverse rotation to bring ray into object space
            vec3 ro = (u_inv_rot * vec4(ro_cam, 1.0)).xyz + vec3(0.5);
            vec3 rd = normalize((u_inv_rot * vec4(rd_cam, 0.0)).xyz);

            // Correct for anisotropic voxel spacing
            rd = rd / u_box_scale;
            ro = ro / u_box_scale;

            // Normalize rd length
            float rd_len = length(rd);
            rd = rd / rd_len;

            // Ray-box intersection
            vec2 t = boxIntersect(ro * u_box_scale, normalize((u_inv_rot * vec4(rd_cam, 0.0)).xyz));
            if (t.y <= t.x || t.y < 0.0) {
                fragColor = vec4(0.0, 0.0, 0.0, 1.0);
                return;
            }

            float tmin = max(t.x, 0.0);
            float tmax = t.y;

            // Front-to-back ray march
            vec4 accum = vec4(0.0);
            vec3 pos;
            vec3 rd_raw = normalize((u_inv_rot * vec4(rd_cam, 0.0)).xyz);

            for (int i = 0; i < 1200; i++) {
                float tt = tmin + float(i) * u_step;
                if (tt > tmax || accum.a > 0.98) break;

                pos = ro_cam / u_zoom;
                // Recompute position along ray
                vec3 p_cam = ro_cam + rd_cam * tt;
                vec3 p_obj = (u_inv_rot * vec4(p_cam, 1.0)).xyz + vec3(0.5);

                if (any(lessThan(p_obj, vec3(0.0))) || any(greaterThan(p_obj, vec3(1.0)))) continue;

                float ct_val = texture(u_vol, p_obj).r;
                float seg_raw = texture(u_seg, p_obj).r;
                int   seg_label = int(seg_raw * 3.0 + 0.5); // decode: 0/85/170 -> 0/1/2

                vec3  color = vec3(0.0);
                float alpha = 0.0;

                if (u_mode == 2) {
                    // seg_only: show colored labels on black bg
                    if (seg_label == 1) { color = vec3(0.0, 1.0, 0.0); alpha = 0.9; }
                    else if (seg_label == 2) { color = vec3(1.0, 1.0, 0.0); alpha = 0.9; }
                } else {
                    // CT channel
                    float cta = ct_val * ct_val * 0.4;  // transfer function
                    color = vec3(ct_val);
                    alpha = cta;

                    if (u_mode == 1) {
                        // overlay: blend seg color on top
                        if (seg_label == 1) {
                            color = mix(color, vec3(0.0, 1.0, 0.0), u_seg_opacity);
                            alpha = max(alpha, u_seg_opacity * 0.8);
                        } else if (seg_label == 2) {
                            color = mix(color, vec3(1.0, 1.0, 0.0), u_seg_opacity);
                            alpha = max(alpha, u_seg_opacity * 0.8);
                        }
                    }
                }

                // Front-to-back compositing
                if (alpha > 0.001) {
                    float a_adj = 1.0 - pow(1.0 - alpha, u_step / 0.004);
                    accum.rgb += (1.0 - accum.a) * color * a_adj;
                    accum.a   += (1.0 - accum.a) * a_adj;
                }
            }

            fragColor = vec4(accum.rgb, 1.0);
        }`;

        const prog = this._compileProgram(vsrc, fsrc);
        if (!prog) return;
        this._program = prog;

        // Full-screen quad
        const verts = new Float32Array([-1,-1, 1,-1, -1,1, 1,1]);
        this._vao = gl.createVertexArray();
        gl.bindVertexArray(this._vao);
        const vbo = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
        gl.bufferData(gl.ARRAY_BUFFER, verts, gl.STATIC_DRAW);
        const loc = gl.getAttribLocation(prog, 'a_pos');
        gl.enableVertexAttribArray(loc);
        gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
        gl.bindVertexArray(null);

        // Create placeholder textures
        this._volTex = this._createTex3D(gl);
        this._segTex = this._createTex3D(gl);

        this._ready = true;
    }

    _createTex3D(gl) {
        const tex = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_3D, tex);
        gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_3D, gl.TEXTURE_WRAP_R, gl.CLAMP_TO_EDGE);
        // 1x1x1 placeholder
        gl.texImage3D(gl.TEXTURE_3D, 0, gl.R8, 1, 1, 1, 0, gl.RED, gl.UNSIGNED_BYTE,
                      new Uint8Array([0]));
        return tex;
    }

    _compileProgram(vsrc, fsrc) {
        const gl = this.gl;
        const compile = (type, src) => {
            const s = gl.createShader(type);
            gl.shaderSource(s, src);
            gl.compileShader(s);
            if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
                console.error('Shader error:', gl.getShaderInfoLog(s));
                return null;
            }
            return s;
        };
        const vs = compile(gl.VERTEX_SHADER, vsrc);
        const fs = compile(gl.FRAGMENT_SHADER, fsrc);
        if (!vs || !fs) return null;
        const prog = gl.createProgram();
        gl.attachShader(prog, vs); gl.attachShader(prog, fs);
        gl.linkProgram(prog);
        if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
            console.error('Program link error:', gl.getProgramInfoLog(prog));
            return null;
        }
        return prog;
    }

    // ---------- Data loading ----------
    async loadCT(filepath, ww, wl) {
        const url = `/api/volume3d?filepath=${encodeURIComponent(filepath)}&ww=${ww}&wl=${wl}&type=ct`;
        try {
            const { data, shape, tilesPerRow, spacing } = await this._fetchAtlas(url);
            this._volShape = shape;
            this._spacing = spacing;
            this._uploadAtlasToTex(this._volTex, data, shape, tilesPerRow);
            this._ctLoaded = true;
            this.render();
        } catch(e) { console.error('CT load error:', e); }
    }

    async loadSeg(filepath) {
        const url = `/api/volume3d?filepath=${encodeURIComponent(filepath)}&type=seg`;
        try {
            const { data, shape, tilesPerRow } = await this._fetchAtlas(url);
            this._uploadAtlasToTex(this._segTex, data, shape, tilesPerRow);
            this._segLoaded = true;
            this.render();
        } catch(e) {
            // No seg available, fill with zeros
            this._clearSegTex();
        }
    }

    clearSeg() {
        this._segLoaded = false;
        this._clearSegTex();
        this.render();
    }

    _clearSegTex() {
        const gl = this.gl;
        if (!gl || !this._segTex) return;
        const [Z, Y, X] = this._volShape;
        const zeros = new Uint8Array(Z * Y * X);
        gl.bindTexture(gl.TEXTURE_3D, this._segTex);
        gl.texImage3D(gl.TEXTURE_3D, 0, gl.R8, X, Y, Z, 0, gl.RED, gl.UNSIGNED_BYTE, zeros);
    }

    async _fetchAtlas(url) {
        const resp = await fetch(url);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        const shapeStr   = resp.headers.get('X-Vol-Shape');    // "Z,Y,X"
        const tilesStr   = resp.headers.get('X-Vol-Tiles');    // tiles_per_row
        const spacingStr = resp.headers.get('X-Vol-Spacing');  // "sx,sy,sz"
        const shape     = shapeStr  ? shapeStr.split(',').map(Number)  : [1,1,1];
        const tilesPerRow = tilesStr ? parseInt(tilesStr) : 1;
        const spacing   = spacingStr ? spacingStr.split(',').map(Number) : [1,1,1];
        const blob = await resp.blob();
        const bmp  = await createImageBitmap(blob);
        // Draw to offscreen canvas to get pixel data
        const oc  = new OffscreenCanvas(bmp.width, bmp.height);
        const ctx = oc.getContext('2d');
        ctx.drawImage(bmp, 0, 0);
        const imgData = ctx.getImageData(0, 0, bmp.width, bmp.height);
        return { data: imgData, shape, tilesPerRow, spacing };
    }

    _uploadAtlasToTex(tex, imgData, shape, tilesPerRow) {
        const gl = this.gl;
        const [Z, Y, X] = shape;
        const pixels = imgData.data;  // RGBA
        // Extract grayscale (R channel from RGBA)
        const vol3d = new Uint8Array(Z * Y * X);
        const atlasW = imgData.width;

        for (let z = 0; z < Z; z++) {
            const tileRow = Math.floor(z / tilesPerRow);
            const tileCol = z % tilesPerRow;
            const ox = tileCol * X;
            const oy = tileRow * Y;
            for (let y = 0; y < Y; y++) {
                for (let x = 0; x < X; x++) {
                    const px = (oy + y) * atlasW + (ox + x);
                    vol3d[z * Y * X + y * X + x] = pixels[px * 4]; // R channel
                }
            }
        }

        gl.bindTexture(gl.TEXTURE_3D, tex);
        gl.texImage3D(gl.TEXTURE_3D, 0, gl.R8, X, Y, Z, 0, gl.RED, gl.UNSIGNED_BYTE, vol3d);
    }

    // ---------- Rendering ----------
    render() {
        const gl = this.gl;
        if (!gl || !this._ready || !this._ctLoaded) {
            // Draw black placeholder
            gl.clearColor(0,0,0,1);
            gl.clear(gl.COLOR_BUFFER_BIT);
            return;
        }

        gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
        gl.clearColor(0.07, 0.07, 0.11, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);

        gl.useProgram(this._program);
        gl.bindVertexArray(this._vao);

        // Bind textures
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_3D, this._volTex);
        gl.uniform1i(gl.getUniformLocation(this._program, 'u_vol'), 0);

        gl.activeTexture(gl.TEXTURE1);
        gl.bindTexture(gl.TEXTURE_3D, this._segTex);
        gl.uniform1i(gl.getUniformLocation(this._program, 'u_seg'), 1);

        // Rotation matrix from quaternion
        const rotMat = this._quatToMat4(this._quat);
        const invRot = this._mat4Invert(rotMat);
        gl.uniformMatrix4fv(gl.getUniformLocation(this._program, 'u_inv_rot'), false, invRot);

        gl.uniform1f(gl.getUniformLocation(this._program, 'u_zoom'), this._zoom);
        gl.uniform1f(gl.getUniformLocation(this._program, 'u_aspect'),
                     gl.canvas.width / gl.canvas.height);
        gl.uniform1f(gl.getUniformLocation(this._program, 'u_step'), this._stepSize);
        gl.uniform1i(gl.getUniformLocation(this._program, 'u_mode'), this._mode);
        gl.uniform1f(gl.getUniformLocation(this._program, 'u_seg_opacity'), this._segOpacity);

        // Normalize spacing so the longest physical dimension = 1
        const [Z, Y, X] = this._volShape;
        const [sx, sy, sz] = this._spacing;
        const phys = [X * sx, Y * sy, Z * sz];
        const maxPhys = Math.max(...phys);
        gl.uniform3f(gl.getUniformLocation(this._program, 'u_box_scale'),
                     phys[0]/maxPhys, phys[1]/maxPhys, phys[2]/maxPhys);

        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        gl.bindVertexArray(null);
    }

    // ---------- Public setters ----------
    setDisplayMode(mode) {
        // mode: 'none'|'original'|'overlay'|'seg_only'
        if (mode === 'none' || mode === 'original') this._mode = 0;
        else if (mode === 'overlay')  this._mode = 1;
        else if (mode === 'seg_only') this._mode = 2;
        this.render();
    }

    setSegOpacity(v) {
        this._segOpacity = v;
        this.render();
    }

    setStepSize(v) {
        this._stepSize = v;
        this.render();
    }

    resetView() {
        this._quat = [0, 0, 0, 1];
        this._zoom = 2.0;
        this.render();
    }

    // ---------- Mouse interaction ----------
    _setupMouseEvents() {
        const c = this.canvas;
        c.addEventListener('mousedown',   e => this._onMouseDown(e));
        c.addEventListener('mousemove',   e => this._onMouseMove(e));
        c.addEventListener('mouseup',     e => { this._isDragging = false; });
        c.addEventListener('mouseleave',  e => { this._isDragging = false; });
        c.addEventListener('wheel',       e => this._onWheel(e), { passive: false });
        c.addEventListener('contextmenu', e => e.preventDefault());
    }

    _onMouseDown(e) {
        if (e.button === 0) {
            this._isDragging = true;
            this._lastMouse = [e.clientX, e.clientY];
        }
    }

    _onMouseMove(e) {
        if (!this._isDragging) return;
        const dx = e.clientX - this._lastMouse[0];
        const dy = e.clientY - this._lastMouse[1];
        this._lastMouse = [e.clientX, e.clientY];

        // Arcball: horizontal drag -> rotate around world Y axis
        //          vertical drag   -> rotate around world X axis
        // Negate signs so drag direction matches visual rotation direction
        const speed = 0.008;
        const angleY = -dx * speed;   // yaw:  drag right -> object rotates right
        const angleX = -dy * speed;   // pitch: drag down -> object tilts down

        // Incremental quaternion for each axis, then combine
        const qx = this._quatFromAxisAngle([1, 0, 0], angleX);
        const qy = this._quatFromAxisAngle([0, 1, 0], angleY);
        // Apply: new_quat = qy * qx * old_quat  (world-space rotation)
        this._quat = this._quatNorm(this._quatMul(this._quatMul(qy, qx), this._quat));
        this.render();
    }

    _onWheel(e) {
        e.preventDefault();
        // scroll up (deltaY < 0) -> zoom in (larger _zoom); scroll down -> zoom out
        this._zoom *= (e.deltaY > 0) ? 0.9 : 1.1;
        this._zoom = Math.max(0.3, Math.min(10.0, this._zoom));
        this.render();
    }

    // ---------- Math utilities ----------
    _quatFromAxisAngle(axis, angle) {
        const half = angle * 0.5;
        const s = Math.sin(half);
        const len = Math.sqrt(axis[0]*axis[0]+axis[1]*axis[1]+axis[2]*axis[2]) || 1;
        return [axis[0]/len*s, axis[1]/len*s, axis[2]/len*s, Math.cos(half)];
    }

    _quatMul(a, b) {
        return [
             a[3]*b[0] + a[0]*b[3] + a[1]*b[2] - a[2]*b[1],
             a[3]*b[1] - a[0]*b[2] + a[1]*b[3] + a[2]*b[0],
             a[3]*b[2] + a[0]*b[1] - a[1]*b[0] + a[2]*b[3],
             a[3]*b[3] - a[0]*b[0] - a[1]*b[1] - a[2]*b[2],
        ];
    }

    _quatNorm(q) {
        const len = Math.sqrt(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]+q[3]*q[3]) || 1;
        return q.map(v => v/len);
    }

    _quatToMat4(q) {
        const [x,y,z,w] = q;
        // Column-major for WebGL
        return new Float32Array([
            1-2*(y*y+z*z),   2*(x*y+z*w),   2*(x*z-y*w), 0,
              2*(x*y-z*w), 1-2*(x*x+z*z),   2*(y*z+x*w), 0,
              2*(x*z+y*w),   2*(y*z-x*w), 1-2*(x*x+y*y), 0,
            0,             0,             0,             1,
        ]);
    }

    _mat4Invert(m) {
        // For rotation matrix, inverse == transpose
        return new Float32Array([
            m[0], m[4], m[8],  m[12],
            m[1], m[5], m[9],  m[13],
            m[2], m[6], m[10], m[14],
            m[3], m[7], m[11], m[15],
        ]);
    }
}

// ============================================================
// State
// ============================================================
const state = {
    filepath: '',
    metadata: null,
    // Slice indices (in volume coordinates: Z, Y, X)
    sliceIndex: { axial: 0, coronal: 0, sagittal: 0 },
    // Max indices
    maxIndex: { axial: 0, coronal: 0, sagittal: 0 },
    // Window width / level
    ww: 400,
    wl: 40,
    // Colormap
    colormap: 'gray',
    invert: false,
    // Loading state
    isLoading: false,
    // Debounce timers
    debounceTimers: {},
    // Segmentation / overlay
    overlayMode: 'none',    // 'none' | 'overlay' | 'seg_only'
    hasSegmentation: false,
    segOpacity: 0.4,
    // Inference
    currentTaskId: null,
    pollTimer: null,
    // 3D volume renderer
    volRenderer: null,
};

// Window presets
const PRESETS = {
    ct_abdomen:     { ww: 400,  wl: 40,    name: '腹窗' },
    ct_bone:        { ww: 2000, wl: 500,   name: '骨窗' },
    ct_lung:        { ww: 1500, wl: -600,  name: '肺窗' },
    ct_brain:       { ww: 80,   wl: 40,    name: '脑窗' },
    ct_mediastinum: { ww: 350,  wl: 50,    name: '纵隔窗' },
    full_range:     { ww: 4000, wl: 0,     name: '全范围' },
};

// ============================================================
// Initialization
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    loadFileList();
    setupCanvasEvents();
    // Initialize WebGL volume renderer
    const canvas3d = document.getElementById('canvas-3d');
    if (canvas3d) {
        state.volRenderer = new VolumeRenderer(canvas3d);
    }
});

// ============================================================
// File List & Loading
// ============================================================
async function loadFileList() {
    try {
        const resp = await fetch('/api/files');
        const data = await resp.json();
        const select = document.getElementById('file-select');
        // Keep first option
        select.innerHTML = '<option value="">-- 选择图像文件 --</option>';
        data.files.forEach(f => {
            const opt = document.createElement('option');
            opt.value = f.path;
            opt.textContent = f.name;
            select.appendChild(opt);
        });
    } catch (e) {
        console.error('Failed to load file list:', e);
    }
}

async function onFileSelected() {
    const select = document.getElementById('file-select');
    const filepath = select.value;
    if (!filepath) return;

    state.isLoading = true;
    showLoading(true);

    try {
        const resp = await fetch('/api/load', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filepath })
        });
        const data = await resp.json();

        if (data.success) {
            state.filepath = filepath;
            state.metadata = data.metadata;

            // numpy_shape is [Z, Y, X]
            const shape = data.metadata.numpy_shape;
            state.maxIndex.axial = shape[0] - 1;
            state.maxIndex.coronal = shape[1] - 1;
            state.maxIndex.sagittal = shape[2] - 1;

            // Set initial slice to middle
            state.sliceIndex.axial = Math.floor(shape[0] / 2);
            state.sliceIndex.coronal = Math.floor(shape[1] / 2);
            state.sliceIndex.sagittal = Math.floor(shape[2] / 2);

            // Auto window: use min/max for initial full range, then apply abdomen preset
            const minVal = data.metadata.min_val;
            const maxVal = data.metadata.max_val;

            // Set WW/WL slider ranges
            document.getElementById('slider-ww').max = Math.ceil(maxVal - minVal);
            document.getElementById('slider-wl').min = Math.floor(minVal);
            document.getElementById('slider-wl').max = Math.ceil(maxVal);

            // Apply default abdomen preset
            setPreset('ct_abdomen');

            // Update sliders
            updateSliders();

            // Update volume info
            updateVolumeInfo();

            // Load histogram
            loadHistogram();

            // Load CT volume into WebGL renderer (async, non-blocking)
            if (state.volRenderer) {
                state.volRenderer._ctLoaded = false;
                state.volRenderer.clearSeg();
                state.volRenderer.loadCT(filepath, state.ww, state.wl);
            }

            // Update all views
            updateAllViews();

            // Check if segmentation already exists
            checkSegmentation();
        } else {
            alert('加载失败: ' + (data.error || '未知错误'));
        }
    } catch (e) {
        console.error('Load error:', e);
        alert('加载失败: ' + e.message);
    } finally {
        state.isLoading = false;
        showLoading(false);
    }
}

function showLoading(show) {
    document.getElementById('loading-indicator').style.display = show ? 'flex' : 'none';
}

// ============================================================
// Volume Info Display
// ============================================================
function updateVolumeInfo() {
    const info = document.getElementById('volume-info');
    if (!state.metadata) {
        info.innerHTML = '<p class="info-text">未加载图像</p>';
        return;
    }
    const m = state.metadata;
    const sp = m.spacing.map(v => v.toFixed(3));
    const org = m.origin.map(v => v.toFixed(2));
    info.innerHTML = `
        <table class="info-table">
            <tr><td>文件:</td><td>${m.filename}</td></tr>
            <tr><td>尺寸:</td><td>${m.size[0]} x ${m.size[1]} x ${m.size[2]}</td></tr>
            <tr><td>间距:</td><td>${sp[0]} x ${sp[1]} x ${sp[2]} mm</td></tr>
            <tr><td>原点:</td><td>(${org[0]}, ${org[1]}, ${org[2]})</td></tr>
            <tr><td>类型:</td><td>${m.dtype}</td></tr>
            <tr><td>范围:</td><td>[${m.min_val.toFixed(1)}, ${m.max_val.toFixed(1)}]</td></tr>
        </table>
    `;

    // Add style for info table if not present
    if (!document.getElementById('info-table-style')) {
        const style = document.createElement('style');
        style.id = 'info-table-style';
        style.textContent = `
            .info-table { font-size: 11px; width: 100%; border-collapse: collapse; }
            .info-table td { padding: 2px 4px; color: #a6adc8; }
            .info-table td:first-child { color: #6c7086; width: 50px; white-space: nowrap; }
        `;
        document.head.appendChild(style);
    }

    // Open the section
    const sec = document.getElementById('sec-volinfo');
    openSection(sec);
}

// ============================================================
// Slider Management
// ============================================================
function updateSliders() {
    ['axial', 'coronal', 'sagittal'].forEach(plane => {
        const slider = document.getElementById(`slider-${plane}`);
        slider.max = state.maxIndex[plane];
        slider.value = state.sliceIndex[plane];
    });
    updatePositionLabels();
}

function updatePositionLabels() {
    if (!state.metadata) return;
    const m = state.metadata;
    // After DICOMOrientImageToCoordinateAxes('RAS'):
    // SimpleITK spacing: [R_spacing, A_spacing, S_spacing]
    // SimpleITK origin: in LPS coordinates
    // Direction: [-1,0,0, 0,-1,0, 0,0,1]
    // numpy axes: [S, A, R]
    //
    // Physical position (LPS) = origin + idx * spacing * direction_diagonal
    // RAS = [-LPS_x, -LPS_y, LPS_z]
    const dir = m.direction; // 9 elements, row-major

    // Axial: slicing along S (numpy axis 0), index k
    // S_lps = origin[2] + k * spacing[2] * dir[8]
    // S_ras = S_lps (S is same in LPS and RAS)
    const k = state.sliceIndex.axial;
    const sPos = m.origin[2] + k * m.spacing[2] * dir[8];
    document.getElementById('pos-axial').textContent = `S: ${sPos.toFixed(1)}mm`;

    // Coronal: slicing along A (numpy axis 1), index j
    // LPS_y = origin[1] + j * spacing[1] * dir[4]
    // A_ras = -LPS_y
    const j = state.sliceIndex.coronal;
    const aPos = -(m.origin[1] + j * m.spacing[1] * dir[4]);
    document.getElementById('pos-coronal').textContent = `A: ${aPos.toFixed(1)}mm`;

    // Sagittal: slicing along R (numpy axis 2), index i
    // LPS_x = origin[0] + i * spacing[0] * dir[0]
    // R_ras = -LPS_x
    const i = state.sliceIndex.sagittal;
    const rPos = -(m.origin[0] + i * m.spacing[0] * dir[0]);
    document.getElementById('pos-sagittal').textContent = `L: ${rPos.toFixed(1)}mm`;
}

function onSliceSlider(plane) {
    const slider = document.getElementById(`slider-${plane}`);
    state.sliceIndex[plane] = parseInt(slider.value);
    updatePositionLabels();
    debouncedUpdateSlice(plane);
}

// ============================================================
// Window Width/Level Controls
// ============================================================
function onWWSlider() {
    const val = parseInt(document.getElementById('slider-ww').value);
    state.ww = val;
    document.getElementById('input-ww').value = val;
    if (state.volRenderer && state.filepath) state.volRenderer.loadCT(state.filepath, state.ww, state.wl);
    debouncedUpdateAllViews();
}

function onWLSlider() {
    const val = parseInt(document.getElementById('slider-wl').value);
    state.wl = val;
    document.getElementById('input-wl').value = val;
    if (state.volRenderer && state.filepath) state.volRenderer.loadCT(state.filepath, state.ww, state.wl);
    debouncedUpdateAllViews();
}

function onWWWLInput() {
    state.ww = parseFloat(document.getElementById('input-ww').value) || 1;
    state.wl = parseFloat(document.getElementById('input-wl').value) || 0;
    document.getElementById('slider-ww').value = state.ww;
    document.getElementById('slider-wl').value = state.wl;
    if (state.volRenderer && state.filepath) state.volRenderer.loadCT(state.filepath, state.ww, state.wl);
    debouncedUpdateAllViews();
}

function setPreset(presetName) {
    const preset = PRESETS[presetName];
    if (!preset) return;

    if (presetName === 'full_range' && state.metadata) {
        state.ww = state.metadata.max_val - state.metadata.min_val;
        state.wl = (state.metadata.max_val + state.metadata.min_val) / 2;
    } else {
        state.ww = preset.ww;
        state.wl = preset.wl;
    }

    document.getElementById('input-ww').value = Math.round(state.ww);
    document.getElementById('input-wl').value = Math.round(state.wl);
    document.getElementById('slider-ww').value = state.ww;
    document.getElementById('slider-wl').value = state.wl;

    updateAllViews();
}

function onDisplayChanged() {
    state.colormap = document.getElementById('colormap-select').value;
    updateAllViews();
}

// ============================================================
// Image Rendering
// ============================================================
function buildSliceUrl(plane) {
    const idx = state.sliceIndex[plane];
    let url = `/api/slice/${plane}/${idx}?filepath=${encodeURIComponent(state.filepath)}&ww=${state.ww}&wl=${state.wl}&colormap=${state.colormap}&invert=0`;
    if (state.hasSegmentation && state.overlayMode !== 'none') {
        url += `&overlay=${state.overlayMode}&seg_opacity=${state.segOpacity}`;
    }
    return url;
}

function update3D() {
    if (!state.filepath || !state.volRenderer) return;
    state.volRenderer.setDisplayMode(state.overlayMode);
    state.volRenderer.setSegOpacity(state.segOpacity);
    state.volRenderer.render();
}

function renderImageToCanvas(canvasId, url) {
    return new Promise((resolve, reject) => {
        const canvas = document.getElementById(canvasId);
        const ctx = canvas.getContext('2d');
        const img = new window.Image();

        img.onload = () => {
            // Resize canvas to match container while maintaining aspect ratio
            const container = canvas.parentElement;
            const containerW = container.clientWidth;
            const containerH = container.clientHeight;

            const imgAspect = img.width / img.height;
            const containerAspect = containerW / containerH;

            let drawW, drawH;
            if (imgAspect > containerAspect) {
                drawW = containerW;
                drawH = containerW / imgAspect;
            } else {
                drawH = containerH;
                drawW = containerH * imgAspect;
            }

            canvas.width = drawW;
            canvas.height = drawH;

            // Always use smooth interpolation
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';

            ctx.drawImage(img, 0, 0, drawW, drawH);
            resolve();
        };

        img.onerror = () => reject(new Error('Image load failed'));
        img.src = url;
    });
}

function updateSlice(plane) {
    if (!state.filepath) return;
    renderImageToCanvas(`canvas-${plane}`, buildSliceUrl(plane));
}

function updateMIP() {
    // Legacy stub - 3D is now handled by VolumeRenderer
}

function updateAllViews() {
    if (!state.filepath) return;
    ['axial', 'coronal', 'sagittal'].forEach(plane => updateSlice(plane));
    update3D();
}

// Debounce utility
function debounce(key, fn, delay = 80) {
    if (state.debounceTimers[key]) {
        clearTimeout(state.debounceTimers[key]);
    }
    state.debounceTimers[key] = setTimeout(fn, delay);
}

function debouncedUpdateSlice(plane) {
    debounce(`slice-${plane}`, () => updateSlice(plane), 50);
}

function debouncedUpdateAllViews() {
    debounce('all-views', () => updateAllViews(), 80);
}

// ============================================================
// Canvas Events (scroll to change slice, mouse for probe)
// ============================================================
function setupCanvasEvents() {
    ['axial', 'coronal', 'sagittal'].forEach(plane => {
        const container = document.getElementById(`view-${plane}`);

        // Mouse wheel to change slice
        container.addEventListener('wheel', (e) => {
            e.preventDefault();
            if (!state.filepath) return;

            const delta = e.deltaY > 0 ? 1 : -1;
            const newIdx = state.sliceIndex[plane] + delta;
            state.sliceIndex[plane] = Math.max(0, Math.min(state.maxIndex[plane], newIdx));
            document.getElementById(`slider-${plane}`).value = state.sliceIndex[plane];
            updatePositionLabels();
            debouncedUpdateSlice(plane);
        });

        // Mouse move for data probe
        const canvas = document.getElementById(`canvas-${plane}`);
        canvas.addEventListener('mousemove', (e) => {
            if (!state.metadata) return;
            const rect = canvas.getBoundingClientRect();
            const x = (e.clientX - rect.left) / rect.width;
            const y = (e.clientY - rect.top) / rect.height;
            updateProbeInfo(plane, x, y);
        });

        // Right-click drag for WW/WL adjustment
        let isDragging = false;
        let dragStartX = 0, dragStartY = 0;
        let dragStartWW = 0, dragStartWL = 0;

        container.addEventListener('mousedown', (e) => {
            if (e.button === 2) { // right click
                e.preventDefault();
                isDragging = true;
                dragStartX = e.clientX;
                dragStartY = e.clientY;
                dragStartWW = state.ww;
                dragStartWL = state.wl;
            }
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const dx = e.clientX - dragStartX;
            const dy = e.clientY - dragStartY;
            state.ww = Math.max(1, dragStartWW + dx * 2);
            state.wl = dragStartWL - dy * 2;
            document.getElementById('input-ww').value = Math.round(state.ww);
            document.getElementById('input-wl').value = Math.round(state.wl);
            document.getElementById('slider-ww').value = state.ww;
            document.getElementById('slider-wl').value = state.wl;
            debouncedUpdateAllViews();
        });

        document.addEventListener('mouseup', (e) => {
            if (e.button === 2) isDragging = false;
        });

        container.addEventListener('contextmenu', (e) => e.preventDefault());
    });
}

// Probe debounce timer
let _probeLabelTimer = null;

function updateProbeInfo(plane, normX, normY) {
    if (!state.metadata) return;
    const m = state.metadata;
    const shape = m.numpy_shape; // [Z, Y, X]

    let voxelStr = '';
    let worldStr = '';
    let iz = 0, iy = 0, ix = 0;

    // normX and normY are in display coordinates (0-1)
    // Display is flipud, so Y is inverted
    const dispY = normY;
    const dispX = normX;

    if (plane === 'axial') {
        // Display: (Y, X) after flipud
        ix = Math.floor(dispX * shape[2]);
        iy = Math.floor((1 - dispY) * shape[1]); // undo flipud
        iz = state.sliceIndex.axial;
        voxelStr = `体素: [${ix}, ${iy}, ${iz}]`;
        const wx = m.origin[0] + ix * m.spacing[0];
        const wy = m.origin[1] + iy * m.spacing[1];
        const wz = m.origin[2] + iz * m.spacing[2];
        worldStr = `RAS: (${wx.toFixed(1)}, ${wy.toFixed(1)}, ${wz.toFixed(1)})`;
    } else if (plane === 'coronal') {
        ix = Math.floor(dispX * shape[2]);
        iz = Math.floor((1 - dispY) * shape[0]);
        iy = state.sliceIndex.coronal;
        voxelStr = `体素: [${ix}, ${iy}, ${iz}]`;
        const wx = m.origin[0] + ix * m.spacing[0];
        const wy = m.origin[1] + iy * m.spacing[1];
        const wz = m.origin[2] + iz * m.spacing[2];
        worldStr = `RAS: (${wx.toFixed(1)}, ${wy.toFixed(1)}, ${wz.toFixed(1)})`;
    } else if (plane === 'sagittal') {
        iy = Math.floor(dispX * shape[1]);
        iz = Math.floor((1 - dispY) * shape[0]);
        ix = state.sliceIndex.sagittal;
        voxelStr = `体素: [${ix}, ${iy}, ${iz}]`;
        const wx = m.origin[0] + ix * m.spacing[0];
        const wy = m.origin[1] + iy * m.spacing[1];
        const wz = m.origin[2] + iz * m.spacing[2];
        worldStr = `RAS: (${wx.toFixed(1)}, ${wy.toFixed(1)}, ${wz.toFixed(1)})`;
    }

    document.getElementById('probe-info').innerHTML =
        `<div>${voxelStr}</div><div>${worldStr}</div>`;
}

// ============================================================
// Histogram
// ============================================================
async function loadHistogram() {
    if (!state.filepath) return;
    try {
        const resp = await fetch(`/api/histogram?filepath=${encodeURIComponent(state.filepath)}`);
        const data = await resp.json();
        drawHistogram(data);
    } catch (e) {
        console.error('Histogram error:', e);
    }
}

function drawHistogram(data) {
    const canvas = document.getElementById('histogram-canvas');
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;

    ctx.fillStyle = '#11111b';
    ctx.fillRect(0, 0, w, h);

    if (!data.counts || data.counts.length === 0) return;

    const counts = data.counts;
    const binEdges = data.bin_edges;
    const maxCount = Math.max(...counts);

    // Draw bars
    const barW = w / counts.length;
    ctx.fillStyle = '#585b70';

    for (let i = 0; i < counts.length; i++) {
        const barH = (counts[i] / maxCount) * (h - 10);
        ctx.fillRect(i * barW, h - barH, barW, barH);
    }

    // Draw WW/WL indicator
    const range = binEdges[binEdges.length - 1] - binEdges[0];
    const lower = state.wl - state.ww / 2;
    const upper = state.wl + state.ww / 2;
    const x1 = ((lower - binEdges[0]) / range) * w;
    const x2 = ((upper - binEdges[0]) / range) * w;

    ctx.fillStyle = 'rgba(137, 180, 250, 0.2)';
    ctx.fillRect(x1, 0, x2 - x1, h);

    ctx.strokeStyle = '#89b4fa';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x1, 0); ctx.lineTo(x1, h);
    ctx.moveTo(x2, 0); ctx.lineTo(x2, h);
    ctx.stroke();

    // Center line (window level)
    const xc = ((state.wl - binEdges[0]) / range) * w;
    ctx.strokeStyle = '#f38ba8';
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(xc, 0); ctx.lineTo(xc, h);
    ctx.stroke();
    ctx.setLineDash([]);
}

// ============================================================
// Section Toggle
// ============================================================
function toggleSection(sectionId) {
    const sec = document.getElementById(sectionId);
    const body = sec.querySelector('.section-body');
    const arrow = sec.querySelector('.arrow');

    if (body.style.display === 'none') {
        body.style.display = 'block';
        if (arrow) arrow.innerHTML = '&#9660;';
        sec.classList.add('open');
    } else {
        body.style.display = 'none';
        if (arrow) arrow.innerHTML = '&#9654;';
        sec.classList.remove('open');
    }
}

function openSection(sec) {
    const body = sec.querySelector('.section-body');
    const arrow = sec.querySelector('.arrow');
    body.style.display = 'block';
    if (arrow) arrow.innerHTML = '&#9660;';
    sec.classList.add('open');
}

// ============================================================
// Window resize handler
// ============================================================
let resizeTimer;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
        if (state.filepath) updateAllViews();
    }, 200);
});

// ============================================================
// Inference
// ============================================================
async function startInference() {
    if (!state.filepath) {
        alert('请先选择并加载一个图像文件');
        return;
    }

    // Find the original input file in imagesTs
    const basename = state.metadata ? state.metadata.filename : '';
    // The loaded file might be a _0000 file from imagesTs or a file from DATA_DIR
    // We need to find the corresponding _0000 file
    let inputPath = state.filepath;

    setInferenceUI(true);

    try {
        const resp = await fetch('/api/inference/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filepath: inputPath })
        });
        const data = await resp.json();

        if (data.error) {
            alert('推理启动失败: ' + data.error);
            setInferenceUI(false);
            return;
        }

        state.currentTaskId = data.task_id;
        pollInferenceProgress(data.task_id);
    } catch (e) {
        alert('推理启动失败: ' + e.message);
        setInferenceUI(false);
    }
}

async function startBatchInference() {
    // Show file selection modal
    try {
        const resp = await fetch('/api/files');
        const data = await resp.json();
        const files = data.files || [];

        const listEl = document.getElementById('batch-file-list');
        listEl.innerHTML = '';
        files.forEach(f => {
            const label = document.createElement('label');
            label.className = 'batch-file-item';
            const cb = document.createElement('input');
            cb.type = 'checkbox';
            cb.value = f.path;
            cb.checked = true;
            label.appendChild(cb);
            label.appendChild(document.createTextNode(' ' + f.name));
            listEl.appendChild(label);
        });

        // Sync select-all state
        document.getElementById('batch-select-all').checked = true;
        document.getElementById('batch-modal').style.display = 'flex';
    } catch(e) {
        alert('无法获取文件列表: ' + e.message);
    }
}

function closeBatchModal() {
    document.getElementById('batch-modal').style.display = 'none';
}

function toggleSelectAll() {
    const checked = document.getElementById('batch-select-all').checked;
    document.querySelectorAll('#batch-file-list input[type=checkbox]').forEach(cb => {
        cb.checked = checked;
    });
}

async function confirmBatchInference() {
    const checkedPaths = [];
    document.querySelectorAll('#batch-file-list input[type=checkbox]:checked').forEach(cb => {
        checkedPaths.push(cb.value);
    });

    if (checkedPaths.length === 0) {
        alert('请至少选择一个案例');
        return;
    }

    closeBatchModal();
    setInferenceUI(true);

    try {
        const resp = await fetch('/api/inference/batch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ files: checkedPaths })
        });
        const data = await resp.json();

        if (data.error) {
            alert('批量推理启动失败: ' + data.error);
            setInferenceUI(false);
            return;
        }

        state.currentTaskId = data.task_id;
        pollInferenceProgress(data.task_id);
    } catch (e) {
        alert('批量推理启动失败: ' + e.message);
        setInferenceUI(false);
    }
}

function pollInferenceProgress(taskId) {
    if (state.pollTimer) clearInterval(state.pollTimer);

    state.pollTimer = setInterval(async () => {
        try {
            const resp = await fetch(`/api/inference/progress/${taskId}`);
            const data = await resp.json();

            updateProgressBar(data.progress || 0, data.message || '');

            if (data.status === 'done') {
                clearInterval(state.pollTimer);
                state.pollTimer = null;
                state.currentTaskId = null;
                onInferenceComplete(data);
            } else if (data.status === 'error' || data.status === 'cancelled') {
                clearInterval(state.pollTimer);
                state.pollTimer = null;
                state.currentTaskId = null;
                setInferenceUI(false);
                if (data.status === 'error') {
                    alert('推理失败: ' + (data.message || '未知错误'));
                }
            }
        } catch (e) {
            console.error('Poll error:', e);
        }
    }, 500);
}

async function cancelInference() {
    if (!state.currentTaskId) return;
    try {
        await fetch(`/api/inference/cancel/${state.currentTaskId}`, { method: 'POST' });
    } catch (e) {
        console.error('Cancel error:', e);
    }
}

function setInferenceUI(running) {
    const progressDiv = document.getElementById('inference-progress');
    const btnInference = document.getElementById('btn-inference');
    const btnBatch = document.getElementById('btn-batch');

    if (running) {
        progressDiv.style.display = 'block';
        btnInference.disabled = true;
        btnBatch.disabled = true;
        updateProgressBar(0, '准备中...');
    } else {
        progressDiv.style.display = 'none';
        btnInference.disabled = false;
        btnBatch.disabled = false;
    }
}

function updateProgressBar(progress, message) {
    const fill = document.getElementById('progress-bar-fill');
    const text = document.getElementById('progress-bar-text');
    const status = document.getElementById('inference-status');

    fill.style.width = progress + '%';
    text.textContent = progress + '%';
    status.textContent = message;
}

function onInferenceComplete(data) {
    setInferenceUI(false);

    // Batch inference: show result tags list
    if (data.results && data.results.length > 0 && data.results[0].case_name) {
        showBatchResults(data.results);
        // Also load the first result automatically
        loadBatchResult(data.results[0]);
        return;
    }

    // Single inference: enable segmentation overlay
    state.hasSegmentation = true;
    state.overlayMode = 'overlay';

    // Load segmentation into WebGL renderer
    if (state.volRenderer) {
        state.volRenderer.loadSeg(state.filepath);
    }

    // Show display mode controls
    document.getElementById('display-mode-group').style.display = 'block';
    document.getElementById('seg-opacity-group').style.display = 'block';

    // Set active button
    setDisplayModeButtonActive('overlay');

    // Refresh all views with overlay
    updateAllViews();
}

function showBatchResults(results) {
    const section = document.getElementById('batch-results-section');
    const list = document.getElementById('batch-results-list');
    list.innerHTML = '';

    results.forEach((item, idx) => {
        const tag = document.createElement('button');
        tag.className = 'batch-result-tag';
        tag.textContent = item.case_name.replace('.nii.gz', '');
        tag.title = item.case_name;
        tag.dataset.idx = idx;
        tag.onclick = () => {
            // Mark active
            list.querySelectorAll('.batch-result-tag').forEach(t => t.classList.remove('active'));
            tag.classList.add('active');
            loadBatchResult(item);
        };
        list.appendChild(tag);
    });

    section.style.display = 'block';
    // Mark first as active
    if (list.firstChild) list.firstChild.classList.add('active');
}

async function loadBatchResult(item) {
    // Load the original input image
    showLoading(true);
    try {
        const resp = await fetch('/api/load', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ filepath: item.input_path })
        });
        const data = await resp.json();
        if (!data.success) {
            alert('加载失败: ' + (data.error || '未知错误'));
            return;
        }

        state.filepath = item.input_path;
        state.metadata = data.metadata;

        const shape = data.metadata.numpy_shape;
        state.maxIndex.axial = shape[0] - 1;
        state.maxIndex.coronal = shape[1] - 1;
        state.maxIndex.sagittal = shape[2] - 1;
        state.sliceIndex.axial = Math.floor(shape[0] / 2);
        state.sliceIndex.coronal = Math.floor(shape[1] / 2);
        state.sliceIndex.sagittal = Math.floor(shape[2] / 2);

        // Update UI
        document.getElementById('file-select').value = item.input_path;
        const minVal = data.metadata.min_val;
        const maxVal = data.metadata.max_val;
        document.getElementById('slider-ww').max = Math.ceil(maxVal - minVal);
        document.getElementById('slider-wl').min = Math.floor(minVal);
        document.getElementById('slider-wl').max = Math.ceil(maxVal);
        setPreset('ct_abdomen');
        updateSliders();
        updateVolumeInfo();
        loadHistogram();

        // Segmentation is already cached in memory by the batch inference thread
        state.hasSegmentation = true;
        state.overlayMode = 'overlay';
        document.getElementById('display-mode-group').style.display = 'block';
        document.getElementById('seg-opacity-group').style.display = 'block';
        setDisplayModeButtonActive('overlay');

        // Load volumes into WebGL renderer
        if (state.volRenderer) {
            state.volRenderer.loadCT(item.input_path, state.ww, state.wl);
            state.volRenderer.loadSeg(item.input_path);
        }

        updateAllViews();
    } catch(e) {
        alert('加载失败: ' + e.message);
    } finally {
        showLoading(false);
    }
}

async function checkSegmentation() {
    if (!state.filepath) return;
    try {
        const resp = await fetch(`/api/segmentation/check?filepath=${encodeURIComponent(state.filepath)}`);
        const data = await resp.json();
        if (data.has_seg) {
            state.hasSegmentation = true;
            state.overlayMode = 'overlay';
            document.getElementById('display-mode-group').style.display = 'block';
            document.getElementById('seg-opacity-group').style.display = 'block';
            setDisplayModeButtonActive('overlay');
            // Load segmentation into WebGL renderer
            if (state.volRenderer) {
                state.volRenderer.loadSeg(state.filepath);
            }
            updateAllViews();
        } else {
            state.hasSegmentation = false;
            state.overlayMode = 'none';
            if (state.volRenderer) state.volRenderer.clearSeg();
            document.getElementById('display-mode-group').style.display = 'none';
            document.getElementById('seg-opacity-group').style.display = 'none';
        }
    } catch (e) {
        console.error('Check segmentation error:', e);
    }
}

// ============================================================
// Display Mode
// ============================================================
function setDisplayMode(mode) {
    state.overlayMode = mode;
    setDisplayModeButtonActive(mode);
    if (state.volRenderer) state.volRenderer.setDisplayMode(mode);
    updateAllViews();
}

function setDisplayModeButtonActive(mode) {
    document.querySelectorAll('.mode-btn').forEach(btn => {
        btn.classList.toggle('active', btn.getAttribute('data-mode') === mode);
    });
}

function onSegOpacityChange() {
    const val = parseInt(document.getElementById('seg-opacity').value);
    state.segOpacity = val / 100;
    document.getElementById('seg-opacity-val').textContent = val + '%';
    if (state.volRenderer) state.volRenderer.setSegOpacity(state.segOpacity);
    debouncedUpdateAllViews();
}

function resetView3D() {
    if (state.volRenderer) state.volRenderer.resetView();
}

function onVolStepChange() {
    const val = parseFloat(document.getElementById('vol-step').value);
    document.getElementById('vol-step-val').textContent = val.toFixed(3);
    if (state.volRenderer) {
        state.volRenderer.setStepSize(val);
    }
}
