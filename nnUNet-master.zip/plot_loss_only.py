"""
从 nnUNet 训练日志中提取 train_loss / val_loss，并绘制仅包含这两条曲线的图。
"""
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

LOG_PATH = Path(
    "/data/nnUNet_data/nnUNet_results/Dataset001_KidneyCyst/"
    "nnUNetTrainer__nnUNetPlans__3d_fullres/fold_0/"
    "training_log_2026_4_3_22_11_23.txt"
)
OUT_PATH = LOG_PATH.parent / "progress_loss_only.png"


def parse_log(path: Path):
    """按 epoch 顺序解析 train_loss 与 val_loss。"""
    train_losses, val_losses = [], []
    cur_train = cur_val = None
    epoch_re = re.compile(r"Epoch\s+(\d+)\s*$")
    train_re = re.compile(r"train_loss\s+(-?\d+\.?\d*)")
    val_re = re.compile(r"val_loss\s+(-?\d+\.?\d*)")

    with path.open("r", encoding="utf-8") as f:
        for line in f:
            if epoch_re.search(line):
                # 进入新 epoch 时，把上一个 epoch 已收集到的写入
                if cur_train is not None and cur_val is not None:
                    train_losses.append(cur_train)
                    val_losses.append(cur_val)
                cur_train = cur_val = None
                continue
            m = train_re.search(line)
            if m:
                cur_train = float(m.group(1))
                continue
            m = val_re.search(line)
            if m:
                cur_val = float(m.group(1))
        # 收尾
        if cur_train is not None and cur_val is not None:
            train_losses.append(cur_train)
            val_losses.append(cur_val)

    return train_losses, val_losses


def main():
    train_losses, val_losses = parse_log(LOG_PATH)
    n = min(len(train_losses), len(val_losses))
    train_losses = train_losses[:n]
    val_losses = val_losses[:n]
    epochs = list(range(n))
    print(f"已解析 {n} 个 epoch 的 loss 数据")

    sns.set_theme(style="darkgrid")
    fig, ax = plt.subplots(figsize=(10, 6), dpi=120)
    ax.plot(epochs, train_losses, color="#1f77b4", linewidth=1.2, label="loss_tr")
    ax.plot(epochs, val_losses, color="#d62728", linewidth=1.2, label="loss_val")
    ax.set_xlabel("epoch")
    ax.set_ylabel("loss")
    ax.set_title(
        "Dataset001_KidneyCyst | nnUNetTrainer__nnUNetPlans__3d_fullres | fold_0"
    )
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(OUT_PATH)
    print(f"图片已保存到: {OUT_PATH}")


if __name__ == "__main__":
    main()
