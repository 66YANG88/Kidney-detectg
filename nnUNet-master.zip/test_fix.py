import SimpleITK as sitk
import os
import numpy as np

img_path = "/root/dataset/label/2_50.nii.gz"
seg_path = "/root/dataset/mask_gt/2_50_seg.nii.gz"

print(f"Reading {img_path}...")
img = sitk.ReadImage(img_path)
print(f"Image Size: {img.GetSize()}")
print(f"Image Origin: {img.GetOrigin()}")
print(f"Image Spacing: {img.GetSpacing()}")
print(f"Image Direction: {img.GetDirection()}")

print(f"Reading {seg_path}...")
seg = sitk.ReadImage(seg_path)
print(f"Seg Size: {seg.GetSize()}")
print(f"Seg Origin: {seg.GetOrigin()}")
print(f"Seg Spacing: {seg.GetSpacing()}")
print(f"Seg Direction: {seg.GetDirection()}")

# Resample Seg to match Image
print("Resampling Seg to match Image...")
resampler = sitk.ResampleImageFilter()
resampler.SetReferenceImage(img)
resampler.SetInterpolator(sitk.sitkNearestNeighbor)
resampler.SetDefaultPixelValue(0)
resampled_seg = resampler.Execute(seg)

# Check if we lost the label (i.e. no overlap)
arr = sitk.GetArrayFromImage(resampled_seg)
unique, counts = np.unique(arr, return_counts=True)
print(f"Resampled Seg unique values: {dict(zip(unique, counts))}")

if len(unique) > 1:
    print("SUCCESS: Overlap detected. Resampling is a valid fix.")
else:
    print("FAILURE: Resampled label is empty. Images do not physically overlap.")
