export nnUNet_raw="/data/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="/data/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="/data/nnUNet_data/nnUNet_results"

echo "nnUNet environment variables set:"
echo "  nnUNet_raw: $nnUNet_raw"
echo "  nnUNet_preprocessed: $nnUNet_preprocessed"
echo "  nnUNet_results: $nnUNet_results"
