import os
import shutil
import json
import SimpleITK as sitk
import numpy as np
from multiprocessing import Pool

# Configuration
SOURCE_IMAGES_DIR = "/root/dataset/label"
SOURCE_LABELS_DIR = "/root/dataset/mask_gt"
NNUNET_RAW = os.environ.get("nnUNet_raw", "/root/nnUNet_data/nnUNet_raw")
DATASET_ID = 1
DATASET_NAME = "KidneyCyst"
DATASET_FULL_NAME = f"Dataset{DATASET_ID:03d}_{DATASET_NAME}"

TARGET_BASE = os.path.join(NNUNET_RAW, DATASET_FULL_NAME)
TARGET_IMAGES_TR = os.path.join(TARGET_BASE, "imagesTr")
TARGET_LABELS_TR = os.path.join(TARGET_BASE, "labelsTr")

def process_case(case_info):
    img_file, src_img_path, src_label_path, dst_img_path, dst_label_path = case_info
    
    try:
        # Read Image
        img = sitk.ReadImage(src_img_path)
        
        # Read Label
        seg = sitk.ReadImage(src_label_path)
        
        # Resample Label to match Image geometry
        # Use Nearest Neighbor for labels to preserve integer class values
        resampler = sitk.ResampleImageFilter()
        resampler.SetReferenceImage(img)
        resampler.SetInterpolator(sitk.sitkNearestNeighbor)
        resampler.SetDefaultPixelValue(0)
        resampled_seg = resampler.Execute(seg)
        
        # Write Image (copy is faster, but using sitk ensures compatibility if we wanted to change something)
        # We can just copy the image file since we want to keep it as is.
        shutil.copy2(src_img_path, dst_img_path)
        
        # Write Resampled Label
        sitk.WriteImage(resampled_seg, dst_label_path)
        
        return True, img_file
    except Exception as e:
        print(f"Error processing {img_file}: {e}")
        return False, img_file

def main():
    # 1. Create directories
    if os.path.exists(TARGET_BASE):
        shutil.rmtree(TARGET_BASE)
    os.makedirs(TARGET_IMAGES_TR, exist_ok=True)
    os.makedirs(TARGET_LABELS_TR, exist_ok=True)
    print(f"Created directories at {TARGET_BASE}")

    # 2. Scan files
    image_files = [f for f in os.listdir(SOURCE_IMAGES_DIR) if f.endswith(".nii.gz")]
    image_files.sort()
    print(f"Found {len(image_files)} image files.")

    tasks = []
    valid_cases = []

    for img_file in image_files:
        case_id = img_file.replace(".nii.gz", "")
        label_file = f"{case_id}_seg.nii.gz"
        
        src_img_path = os.path.join(SOURCE_IMAGES_DIR, img_file)
        src_label_path = os.path.join(SOURCE_LABELS_DIR, label_file)
        
        if not os.path.exists(src_label_path):
            print(f"Warning: Label file not found for {img_file}. Skipping.")
            continue
            
        new_case_id = f"case_{case_id}"
        new_img_name = f"{new_case_id}_0000.nii.gz"
        new_label_name = f"{new_case_id}.nii.gz"
        
        dst_img_path = os.path.join(TARGET_IMAGES_TR, new_img_name)
        dst_label_path = os.path.join(TARGET_LABELS_TR, new_label_name)
        
        tasks.append((img_file, src_img_path, src_label_path, dst_img_path, dst_label_path))
        valid_cases.append(new_case_id)

    # 3. Process files (Serial or Parallel)
    # Using simple loop for better error printing, or Pool for speed. 
    # Given 100 files, serial is fine, but Pool is faster.
    print(f"Processing {len(tasks)} cases...")
    
    # Serial execution to be safe and avoid complexity
    success_count = 0
    for task in tasks:
        success, name = process_case(task)
        if success:
            success_count += 1
        else:
            print(f"Failed: {name}")

    print(f"Successfully processed {success_count} cases.")

    # 4. Create dataset.json
    dataset_json = {
        "channel_names": {
            "0": "CT"
        },
        "labels": {
            "background": 0,
            "Kidney": 1,
            "Kidney Cyst": 2
        },
        "numTraining": success_count,
        "file_ending": ".nii.gz",
        "name": DATASET_NAME,
        "description": "Kidney Cyst Segmentation",
        "reference": "Custom Dataset",
        "licence": "N/A",
        "release": "1.0",
        "tensorImageSize": "3D", 
        "modality": {
             "0": "CT"
        }
    }
    
    json_path = os.path.join(TARGET_BASE, "dataset.json")
    with open(json_path, 'w') as f:
        json.dump(dataset_json, f, indent=4)
        
    print(f"Created dataset.json at {json_path}")

if __name__ == "__main__":
    main()
