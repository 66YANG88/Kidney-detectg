import os
import shutil
import json
from pathlib import Path

# Configuration
SOURCE_IMAGES_DIR = "/root/dataset/label"  # User said 'label' folder contains raw images
SOURCE_LABELS_DIR = "/root/dataset/mask_gt" # User said 'mask_gt' folder contains labels
NNUNET_RAW = os.environ.get("nnUNet_raw", "/root/nnUNet_data/nnUNet_raw")
DATASET_ID = 1
DATASET_NAME = "KidneyCyst"
DATASET_FULL_NAME = f"Dataset{DATASET_ID:03d}_{DATASET_NAME}"

TARGET_BASE = os.path.join(NNUNET_RAW, DATASET_FULL_NAME)
TARGET_IMAGES_TR = os.path.join(TARGET_BASE, "imagesTr")
TARGET_LABELS_TR = os.path.join(TARGET_BASE, "labelsTr")

def main():
    # 1. Create directories
    os.makedirs(TARGET_IMAGES_TR, exist_ok=True)
    os.makedirs(TARGET_LABELS_TR, exist_ok=True)
    print(f"Created directories at {TARGET_BASE}")

    # 2. Scan files
    image_files = [f for f in os.listdir(SOURCE_IMAGES_DIR) if f.endswith(".nii.gz")]
    print(f"Found {len(image_files)} image files.")

    # 3. Copy and rename files
    valid_cases = []
    
    for img_file in image_files:
        # Extract ID (e.g., "10.nii.gz" -> "10")
        case_id = img_file.replace(".nii.gz", "")
        
        # Expected label file (e.g., "10_seg.nii.gz")
        label_file = f"{case_id}_seg.nii.gz"
        
        src_img_path = os.path.join(SOURCE_IMAGES_DIR, img_file)
        src_label_path = os.path.join(SOURCE_LABELS_DIR, label_file)
        
        if not os.path.exists(src_label_path):
            print(f"Warning: Label file not found for {img_file} (expected {label_file}). Skipping.")
            continue
            
        # Define new names
        # Use case_ID format
        new_case_id = f"case_{case_id}"
        new_img_name = f"{new_case_id}_0000.nii.gz"
        new_label_name = f"{new_case_id}.nii.gz"
        
        dst_img_path = os.path.join(TARGET_IMAGES_TR, new_img_name)
        dst_label_path = os.path.join(TARGET_LABELS_TR, new_label_name)
        
        # Copy files
        shutil.copy2(src_img_path, dst_img_path)
        shutil.copy2(src_label_path, dst_label_path)
        
        valid_cases.append(new_case_id)
        
    print(f"Successfully processed {len(valid_cases)} cases.")

    # 4. Create dataset.json
    dataset_json = {
        "channel_names": {
            "0": "CT"
        },
        "labels": {
            "background": 0,
            "Kidney": 1,
            "Kidney Cyst": 2
        },
        "numTraining": len(valid_cases),
        "file_ending": ".nii.gz",
        "name": DATASET_NAME,
        "description": "Kidney Cyst Segmentation"
    }
    
    json_path = os.path.join(TARGET_BASE, "dataset.json")
    with open(json_path, 'w') as f:
        json.dump(dataset_json, f, indent=4)
        
    print(f"Created dataset.json at {json_path}")

if __name__ == "__main__":
    main()
